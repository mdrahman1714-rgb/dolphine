/* Dolphine — where the portal's data lives.

   Two backends behind one interface:

   shared  the deployed site, talking to /api. Applications and documents live
           on the server, so Sam, Topu and Kawser all see the same table.
   local   the same portal opened straight from a file, with no server behind
           it. Everything stays in that one browser — useful for a quick look,
           but nothing is shared.

   Store.init() picks the backend by asking the server whether it is there. */
(function (global) {
  'use strict';

  var DEFAULT_MEMBERS = [
    { id: 'sam', name: 'Sam', color: '#0ea5e9', pin: '1111' },
    { id: 'topu', name: 'Topu', color: '#f59e0b', pin: '2222' },
    { id: 'kawser', name: 'Kawser', color: '#ec4899', pin: '1568' }
  ];
  var MEMBERS_REVISION = 3;
  var MEMBER_COLORS = ['#0ea5e9', '#f59e0b', '#ec4899', '#10b981', '#8b5cf6',
                       '#ef4444', '#14b8a6', '#f97316', '#6366f1', '#84cc16'];

  var KEY_MEMBERS = 'dolphine.members';
  var KEY_MEMBERS_REV = 'dolphine.membersRevision';
  var KEY_APPS = 'dolphine.applications';
  var KEY_SESSION = 'dolphine.session';

  /* Images are shrunk before upload: a phone photo of a passport is many times
     larger than it needs to be. Anything still big — a scanned PDF, typically —
     goes up in pieces, because a single request to the server is capped far
     below the size of a real scan. */
  var MAX_IMAGE_WIDTH = 2000;
  var IMAGE_QUALITY = 0.85;
  var SINGLE_SHOT = 3 * 1024 * 1024;
  var CHUNK_SIZE = 3 * 1024 * 1024;
  var MAX_UPLOAD = 25 * 1024 * 1024;

  var mode = 'local';

  /* ------------------------------- helpers ------------------------------ */

  function readLocal(key, fallback) {
    try {
      var raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) { return fallback; }
  }

  function writeLocal(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; }
    catch (e) { return false; }
  }

  function request(path, options) {
    var opts = options || {};
    opts.credentials = 'same-origin';
    opts.headers = opts.headers || {};
    return fetch(path, opts).then(function (res) {
      if (res.status === 204) return null;
      var isJson = (res.headers.get('content-type') || '').indexOf('json') !== -1;
      return (isJson ? res.json() : res.text()).then(function (body) {
        if (!res.ok) {
          var message = body && body.error ? body.error
            : res.status === 413 ? 'That file is too large for the portal to accept.'
            : res.status === 401 ? 'Your session has expired — please sign in again.'
            : 'The portal could not be reached (' + res.status + '). Please try again.';
          var err = new Error(message);
          err.status = res.status;
          throw err;
        }
        return body;
      });
    });
  }

  /* Shrinks images; leaves PDFs and other files untouched. */
  function prepareUpload(file) {
    if (!/^image\//.test(file.type) || file.type === 'image/gif') {
      return Promise.resolve(file);
    }
    return new Promise(function (resolve) {
      var reader = new FileReader();
      reader.onerror = function () { resolve(file); };
      reader.onload = function () {
        var img = new Image();
        img.onerror = function () { resolve(file); };
        img.onload = function () {
          var scale = Math.min(1, MAX_IMAGE_WIDTH / img.naturalWidth);
          if (scale === 1 && file.size < 1024 * 1024) { resolve(file); return; }
          var canvas = document.createElement('canvas');
          canvas.width = Math.round(img.naturalWidth * scale);
          canvas.height = Math.round(img.naturalHeight * scale);
          canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
          canvas.toBlob(function (blob) {
            if (!blob || blob.size >= file.size) { resolve(file); return; }
            blob.name = file.name.replace(/\.(png|webp|bmp|tiff?)$/i, '.jpg');
            resolve(blob);
          }, 'image/jpeg', IMAGE_QUALITY);
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  /* ------------------------------ local mode ---------------------------- */

  var local = {
    members: function () {
      var list = readLocal(KEY_MEMBERS, null);
      if (!list || !list.length) {
        list = DEFAULT_MEMBERS.map(function (m) { return Object.assign({}, m); });
        writeLocal(KEY_MEMBERS, list);
        writeLocal(KEY_MEMBERS_REV, MEMBERS_REVISION);
      } else if (readLocal(KEY_MEMBERS_REV, 1) !== MEMBERS_REVISION) {
        DEFAULT_MEMBERS.forEach(function (d) {
          var m = list.filter(function (x) { return x.id === d.id; })[0];
          if (m) { m.name = d.name; m.pin = d.pin; m.color = d.color; }
        });
        writeLocal(KEY_MEMBERS, list);
        writeLocal(KEY_MEMBERS_REV, MEMBERS_REVISION);
      }
      return Promise.resolve(list);
    },

    addMember: function (member) {
      return local.members().then(function (list) {
        list.push(member);
        writeLocal(KEY_MEMBERS, list);
        return list;
      });
    },

    removeMember: function (id) {
      return local.members().then(function (list) {
        var kept = list.filter(function (m) { return m.id !== id; });
        writeLocal(KEY_MEMBERS, kept);
        return kept;
      });
    },

    session: function () {
      var stored = readLocal(KEY_SESSION, null);
      if (!stored) return Promise.resolve(null);
      return local.members().then(function (list) {
        return list.filter(function (m) { return m.id === stored.memberId; })[0] || null;
      });
    },

    signIn: function (pin, memberId) {
      return local.members().then(function (list) {
        var matches = list.filter(function (m) { return m.pin === pin; });
        var member = memberId ? list.filter(function (m) { return m.id === memberId; })[0] : null;
        if (member && member.pin !== pin) throw new Error('That PIN does not match ' + member.name + '.');
        if (!member) {
          if (matches.length !== 1) {
            throw new Error(matches.length > 1
              ? 'More than one member uses that PIN — tap your name above as well.'
              : 'Tap your name above, then enter your PIN.');
          }
          member = matches[0];
        }
        writeLocal(KEY_SESSION, { memberId: member.id, at: new Date().toISOString() });
        return member;
      });
    },

    signOut: function () {
      localStorage.removeItem(KEY_SESSION);
      return Promise.resolve();
    },

    listApps: function () { return Promise.resolve(readLocal(KEY_APPS, []) || []); },

    saveApp: function (app) {
      return local.listApps().then(function (apps) {
        var i = apps.findIndex(function (a) { return a.id === app.id; });
        if (i === -1) apps.push(app); else apps[i] = app;
        if (!writeLocal(KEY_APPS, apps)) throw new Error('This browser’s storage is full.');
        return app;
      });
    },

    deleteApp: function (id) {
      return local.listApps().then(function (apps) {
        writeLocal(KEY_APPS, apps.filter(function (a) { return a.id !== id; }));
      });
    },

    saveFile: function (file, by) { return LocalFiles.save(file, by); },
    openFile: function (id) { return LocalFiles.open(id); },
    readFile: function (id) { return LocalFiles.read(id); },
    deleteFile: function (id) { return LocalFiles.remove(id); }
  };

  /* ----------------------------- shared mode ---------------------------- */

  var shared = {
    members: function () { return request('/api/members'); },

    addMember: function () {
      return Promise.reject(new Error(
        'On the shared portal, members are set in Netlify under Site configuration → ' +
        'Environment variables → PORTAL_PINS.'));
    },

    removeMember: function () { return shared.addMember(); },

    session: function () {
      return request('/api/session').then(function (body) {
        return (body && body.member) || null;
      }).catch(function (err) {
        if (err.status === 401) return null;
        throw err;
      });
    },

    signIn: function (pin) {
      return request('/api/session', {
        method: 'POST',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify({ pin: pin })
      });
    },

    signOut: function () { return request('/api/session', { method: 'DELETE' }); },

    listApps: function () { return request('/api/apps'); },

    saveApp: function (app) {
      return request('/api/apps/' + encodeURIComponent(app.id), {
        method: 'PUT',
        headers: { 'content-type': 'application/json' },
        body: JSON.stringify(app)
      });
    },

    deleteApp: function (id) {
      return request('/api/apps/' + encodeURIComponent(id), { method: 'DELETE' });
    },

    saveFile: function (file) {
      return prepareUpload(file).then(function (payload) {
        var name = payload.name || file.name;
        var type = payload.type || 'application/octet-stream';

        if (payload.size > MAX_UPLOAD) {
          throw new Error('“' + name + '” is ' + Math.round(payload.size / 1048576) +
            ' MB. The portal accepts documents up to 25 MB — please scan it at a ' +
            'lower resolution, or split it.');
        }

        var headers = function (extra) {
          var h = {
            'content-type': type,
            'x-file-name': encodeURIComponent(name),
            'x-file-type': type
          };
          Object.keys(extra || {}).forEach(function (k) { h[k] = extra[k]; });
          return h;
        };

        if (payload.size <= SINGLE_SHOT) {
          return request('/api/files', { method: 'POST', headers: headers(), body: payload });
        }

        /* one piece at a time, in order — the last one tells the server to put
           them back together and hands back the finished document */
        var uploadId = (global.crypto && global.crypto.randomUUID)
          ? global.crypto.randomUUID()
          : 'u-' + Date.now() + '-' + Math.random().toString(16).slice(2, 10);
        var count = Math.ceil(payload.size / CHUNK_SIZE);
        var sent = Promise.resolve(null);

        for (var i = 0; i < count; i++) {
          (function (index) {
            sent = sent.then(function (previous) {
              var start = index * CHUNK_SIZE;
              return request('/api/files', {
                method: 'POST',
                headers: headers({
                  'x-upload-id': uploadId,
                  'x-chunk-index': String(index),
                  'x-chunk-count': String(count)
                }),
                body: payload.slice(start, Math.min(start + CHUNK_SIZE, payload.size))
              }).then(function (body) { return index === count - 1 ? body : previous; });
            });
          })(i);
        }
        return sent;
      });
    },

    openFile: function (id) {
      global.open('/api/files/' + encodeURIComponent(id), '_blank');
      return Promise.resolve();
    },

    readFile: function (id) {
      return fetch('/api/files/' + encodeURIComponent(id), { credentials: 'same-origin' })
        .then(function (res) { return res.ok ? res.blob() : null; });
    },

    deleteFile: function (id) {
      return request('/api/files/' + encodeURIComponent(id), { method: 'DELETE' })
        .catch(function () { /* the application is going away regardless */ });
    }
  };

  /* --------------------- documents in browser-only mode ------------------ */

  var LocalFiles = (function () {
    var DB_NAME = 'dolphine-portal';
    var STORE = 'files';
    var FALLBACK_KEY = 'dolphine.files.fallback';
    var FALLBACK_MAX = 1.5 * 1024 * 1024;
    var dbPromise = null;
    var backend = null;

    function openDB() {
      return new Promise(function (resolve, reject) {
        var req;
        try { req = indexedDB.open(DB_NAME, 1); }
        catch (e) { reject(e); return; }
        req.onupgradeneeded = function () {
          if (!req.result.objectStoreNames.contains(STORE)) {
            req.result.createObjectStore(STORE, { keyPath: 'id' });
          }
        };
        req.onsuccess = function () { resolve(req.result); };
        req.onerror = function () { reject(req.error); };
        req.onblocked = function () { reject(new Error('IndexedDB blocked')); };
      });
    }

    function ready() {
      if (dbPromise) return dbPromise;
      dbPromise = (global.indexedDB ? openDB() : Promise.reject(new Error('no indexedDB')))
        .then(function (db) { backend = 'idb'; return db; })
        .catch(function () { backend = 'fallback'; return null; });
      return dbPromise;
    }

    function tx(mode_, run) {
      return ready().then(function (db) {
        return new Promise(function (resolve, reject) {
          var t = db.transaction(STORE, mode_);
          var req = run(t.objectStore(STORE));
          t.oncomplete = function () { resolve(req ? req.result : undefined); };
          t.onerror = function () { reject(t.error); };
          t.onabort = function () { reject(t.error); };
        });
      });
    }

    function fbAll() {
      try { return JSON.parse(localStorage.getItem(FALLBACK_KEY) || '{}'); }
      catch (e) { return {}; }
    }

    function dataUrlToBlob(dataUrl) {
      var parts = dataUrl.split(',');
      var type = (parts[0].match(/:(.*?);/) || [, 'application/octet-stream'])[1];
      var bin = atob(parts[1]);
      var bytes = new Uint8Array(bin.length);
      for (var i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
      return new Blob([bytes], { type: type });
    }

    function newId() {
      if (global.crypto && global.crypto.randomUUID) return global.crypto.randomUUID();
      return 'f-' + Date.now() + '-' + Math.random().toString(16).slice(2, 10);
    }

    return {
      save: function (file, by) {
        var meta = {
          id: newId(),
          name: file.name,
          size: file.size,
          type: file.type || 'application/octet-stream',
          uploadedBy: by || '',
          uploadedAt: new Date().toISOString()
        };
        return ready().then(function () {
          if (backend === 'idb') {
            return tx('readwrite', function (store) {
              store.put(Object.assign({ blob: file }, meta));
            });
          }
          if (file.size > FALLBACK_MAX) {
            throw new Error('“' + file.name + '” is too large to store in this mode. ' +
              'Use the portal on its web address to upload full-size scans.');
          }
          return new Promise(function (resolve, reject) {
            var r = new FileReader();
            r.onerror = function () { reject(r.error); };
            r.onload = function () {
              var all = fbAll();
              all[meta.id] = Object.assign({ dataUrl: r.result }, meta);
              localStorage.setItem(FALLBACK_KEY, JSON.stringify(all));
              resolve();
            };
            r.readAsDataURL(file);
          });
        }).then(function () { return meta; });
      },

      read: function (id) {
        return ready().then(function () {
          if (backend === 'idb') return tx('readonly', function (store) { return store.get(id); });
          var rec = fbAll()[id];
          return rec ? dataUrlToBlob(rec.dataUrl) : null;
        }).then(function (rec) {
          return rec && rec.blob ? rec.blob : rec;
        });
      },

      open: function (id) {
        return ready().then(function () {
          if (backend === 'idb') return tx('readonly', function (store) { return store.get(id); });
          var rec = fbAll()[id];
          return rec ? Object.assign({}, rec, { blob: dataUrlToBlob(rec.dataUrl) }) : null;
        }).then(function (rec) {
          if (!rec) { alert('That document is not stored in this browser.'); return; }
          var url = URL.createObjectURL(rec.blob);
          if (!global.open(url, '_blank')) {
            var a = document.createElement('a');
            a.href = url; a.download = rec.name; a.click();
          }
          setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
        });
      },

      remove: function (id) {
        if (!id) return Promise.resolve();
        return ready().then(function () {
          if (backend === 'idb') return tx('readwrite', function (store) { store.delete(id); });
          var all = fbAll();
          delete all[id];
          localStorage.setItem(FALLBACK_KEY, JSON.stringify(all));
        });
      }
    };
  })();

  /* --------------------------------- api -------------------------------- */

  var active = local;

  var Store = {
    /* Resolves with 'shared' or 'local'. The server is only there on the
       deployed site, so a copy opened from disk quietly stays local. */
    init: function () {
      if (!global.fetch || location.protocol === 'file:') {
        mode = 'local';
        active = local;
        return Promise.resolve(mode);
      }
      return fetch('/api/members', { credentials: 'same-origin' })
        .then(function (res) {
          if (!res.ok) throw new Error('no api');
          return res.json();
        })
        .then(function (list) {
          if (!Array.isArray(list) || !list.length) throw new Error('no members');
          mode = 'shared';
          active = shared;
          return mode;
        })
        .catch(function () {
          mode = 'local';
          active = local;
          return mode;
        });
    },

    mode: function () { return mode; },
    isShared: function () { return mode === 'shared'; },
    memberColors: MEMBER_COLORS,

    members: function () { return active.members(); },
    addMember: function (m) { return active.addMember(m); },
    removeMember: function (id) { return active.removeMember(id); },
    session: function () { return active.session(); },
    signIn: function (pin, memberId) { return active.signIn(pin, memberId); },
    signOut: function () { return active.signOut(); },
    listApps: function () { return active.listApps(); },
    saveApp: function (app) { return active.saveApp(app); },
    deleteApp: function (id) { return active.deleteApp(id); },
    saveFile: function (file, by) { return active.saveFile(file, by); },
    openFile: function (id) { return active.openFile(id); },
    readFile: function (id) { return active.readFile(id); },
    deleteFile: function (id) { return active.deleteFile(id); }
  };

  global.Store = Store;
})(window);
