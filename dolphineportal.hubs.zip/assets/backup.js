/* Dolphine — download everything as a zip.

   A backup you can open without the portal: the applications as readable JSON
   and a CSV, and every uploaded document under its own name. Written by hand
   because a zip that only stores (never compresses) is a short, exact format,
   and scans are already compressed anyway. */
(function (global) {
  'use strict';

  /* ------------------------------- crc32 -------------------------------- */

  var CRC_TABLE = (function () {
    var table = new Uint32Array(256);
    for (var n = 0; n < 256; n++) {
      var c = n;
      for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      table[n] = c >>> 0;
    }
    return table;
  })();

  function crc32(bytes) {
    var c = 0xFFFFFFFF;
    for (var i = 0; i < bytes.length; i++) {
      c = CRC_TABLE[(c ^ bytes[i]) & 0xFF] ^ (c >>> 8);
    }
    return (c ^ 0xFFFFFFFF) >>> 0;
  }

  /* -------------------------------- zip --------------------------------- */

  function dosDateTime(date) {
    var d = date || new Date();
    var year = Math.max(1980, d.getFullYear());
    return {
      time: (d.getHours() << 11) | (d.getMinutes() << 5) | Math.floor(d.getSeconds() / 2),
      date: ((year - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()
    };
  }

  function writer(size) {
    var bytes = new Uint8Array(size);
    var view = new DataView(bytes.buffer);
    var at = 0;
    return {
      bytes: bytes,
      u16: function (v) { view.setUint16(at, v, true); at += 2; },
      u32: function (v) { view.setUint32(at, v >>> 0, true); at += 4; },
      raw: function (chunk) { bytes.set(chunk, at); at += chunk.length; },
      offset: function () { return at; }
    };
  }

  /* entries: [{ name, bytes, date }] -> Blob */
  function zip(entries) {
    var encoder = new TextEncoder();
    var prepared = entries.map(function (entry) {
      var name = encoder.encode(entry.name);
      return {
        name: name,
        data: entry.bytes,
        crc: crc32(entry.bytes),
        stamp: dosDateTime(entry.date)
      };
    });

    var localSize = prepared.reduce(function (n, e) { return n + 30 + e.name.length + e.data.length; }, 0);
    var centralSize = prepared.reduce(function (n, e) { return n + 46 + e.name.length; }, 0);
    var out = writer(localSize + centralSize + 22);
    var offsets = [];

    prepared.forEach(function (e) {
      offsets.push(out.offset());
      out.u32(0x04034b50);
      out.u16(20);            /* version needed */
      out.u16(0x0800);        /* names are UTF-8 */
      out.u16(0);             /* stored, not compressed */
      out.u16(e.stamp.time);
      out.u16(e.stamp.date);
      out.u32(e.crc);
      out.u32(e.data.length);
      out.u32(e.data.length);
      out.u16(e.name.length);
      out.u16(0);
      out.raw(e.name);
      out.raw(e.data);
    });

    var centralStart = out.offset();
    prepared.forEach(function (e, i) {
      out.u32(0x02014b50);
      out.u16(20);            /* version made by */
      out.u16(20);            /* version needed */
      out.u16(0x0800);
      out.u16(0);
      out.u16(e.stamp.time);
      out.u16(e.stamp.date);
      out.u32(e.crc);
      out.u32(e.data.length);
      out.u32(e.data.length);
      out.u16(e.name.length);
      out.u16(0);             /* extra */
      out.u16(0);             /* comment */
      out.u16(0);             /* disk */
      out.u16(0);             /* internal attrs */
      out.u32(0);             /* external attrs */
      out.u32(offsets[i]);
      out.raw(e.name);
    });

    var centralEnd = out.offset();
    out.u32(0x06054b50);
    out.u16(0);                       /* this disk */
    out.u16(0);                       /* disk holding the central directory */
    out.u16(prepared.length);
    out.u16(prepared.length);
    out.u32(centralEnd - centralStart);
    out.u32(centralStart);
    out.u16(0);                       /* no comment */

    return new Blob([out.bytes], { type: 'application/zip' });
  }

  /* Keeps a filename usable on Windows, macOS and Linux alike. */
  function safeName(name, fallback) {
    var cleaned = String(name || '').replace(/[\\/:*?"<>|\x00-\x1F]/g, '_').trim();
    return cleaned || fallback;
  }

  global.Backup = { zip: zip, crc32: crc32, safeName: safeName };
})(window);
