/* Dolphine — Visa Application Portal
   Screens, table and forms. Where the data actually lives — shared on the
   server, or in this browser alone — is Store's business (assets/store.js). */
(function () {
  'use strict';

  /* ------------------------------- config ------------------------------- */

  /* Opening-screen photo. Drop your dolphin photo in as assets/dolphin.jpg and
     it takes over the login background; if the file is missing, the painted
     ocean scene below it is used instead. A data: URI works here too, which is
     what the single-file build uses. A photo chosen from the login screen wins
     over both. */
  var HERO_IMAGE = 'assets/dolphin.jpg';
  var HERO_MAX_WIDTH = 1920;   /* photos are downscaled to this before storing */

  var VISA_TYPES = [
    'Anything Suitable',
    'e-Tourist Visa', 'Tourist Visa', 'Business Visa', 'Medical Visa',
    'Medical Attendant Visa', 'Conference Visa', 'Student Visa',
    'Employment Visa', 'Journalist Visa', 'Transit Visa',
    'Entry (X) Visa', 'Research Visa', 'Other'
  ];

  var STATUSES = [
    { key: 'draft',     label: 'Draft' },
    { key: 'pending',   label: 'Documents Pending' },
    { key: 'review',    label: 'In Review' },
    { key: 'submitted', label: 'Submitted' },
    { key: 'approved',  label: 'Approved' },
    { key: 'rejected',  label: 'Rejected' },
    { key: 'hold',      label: 'On Hold' }
  ];

  var FIELD_LABELS = {
    memberId: 'Member', applicant: 'Applicant', passportNo: 'Passport number',
    passportFile: 'Passport upload', visaType: 'Indian visa type',
    visaFile: 'Indian visa picture',
    reference: 'Reference', startAt: 'Process start', docs: 'Additional documents',
    status: 'Status', note: 'Note'
  };

  var KEY_HERO = 'dolphine.hero';

  /* -------------------------------- state ------------------------------- */

  var members = [];
  var apps = [];
  var session = null;
  var selectedMemberId = null;

  /* ------------------------------- helpers ------------------------------ */

  function $(sel, root) { return (root || document).querySelector(sel); }
  function $$(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }

  function esc(v) {
    return String(v == null ? '' : v)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function uid(prefix) {
    if (window.crypto && window.crypto.randomUUID) return prefix + '-' + window.crypto.randomUUID();
    return prefix + '-' + Date.now() + '-' + Math.random().toString(16).slice(2, 8);
  }

  function read(key, fallback) {
    try {
      var raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) { return fallback; }
  }

  function write(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); }
    catch (e) { alert('Could not save — this browser’s storage is full.'); }
  }

  function memberById(id) {
    for (var i = 0; i < members.length; i++) if (members[i].id === id) return members[i];
    return null;
  }

  function memberName(id) {
    var m = memberById(id);
    return m ? m.name : '—';
  }

  function statusLabel(key) {
    for (var i = 0; i < STATUSES.length; i++) if (STATUSES[i].key === key) return STATUSES[i].label;
    return 'Draft';
  }

  function fmtDateTime(iso) {
    if (!iso) return '';
    var d = new Date(iso);
    if (isNaN(d)) return '';
    return d.toLocaleString(undefined, {
      day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit'
    });
  }

  function fmtSize(bytes) {
    if (!bytes && bytes !== 0) return '';
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(0) + ' KB';
    return (bytes / 1024 / 1024).toFixed(1) + ' MB';
  }

  function relative(iso) {
    if (!iso) return '';
    var diff = Date.now() - new Date(iso).getTime();
    if (isNaN(diff)) return '';
    var mins = Math.round(diff / 60000);
    if (Math.abs(mins) < 1) return 'just now';
    if (Math.abs(mins) < 60) return mins + 'm ago';
    var hrs = Math.round(mins / 60);
    if (Math.abs(hrs) < 24) return hrs + 'h ago';
    var days = Math.round(hrs / 24);
    if (Math.abs(days) < 30) return days + 'd ago';
    return Math.round(days / 30) + 'mo ago';
  }

  /* datetime-local <-> ISO */
  function isoToLocalInput(iso) {
    if (!iso) return '';
    var d = new Date(iso);
    if (isNaN(d)) return '';
    var pad = function (n) { return String(n).padStart(2, '0'); };
    return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) +
           'T' + pad(d.getHours()) + ':' + pad(d.getMinutes());
  }

  function localInputToIso(value) {
    if (!value) return '';
    var d = new Date(value);
    return isNaN(d) ? '' : d.toISOString();
  }

  /* ------------------------------ persistence --------------------------- */

  function loadAll() {
    return Store.members().then(function (list) {
      members = list;
      return Store.session();
    }).then(function (me) {
      session = me;
    });
  }

  /* Applications are saved one at a time so two members editing different rows
     never overwrite each other. */
  function persist(app) {
    return Store.saveApp(app).then(function (saved) {
      refreshStorage();
      return saved;
    }).catch(function (err) {
      alert('That change could not be saved: ' + err.message);
      return refreshApps();
    });
  }

  function refreshApps() {
    return Store.listApps().then(function (list) {
      apps = list || [];
      if (session) render();
    }).catch(function () { /* keep showing what we already have */ });
  }

  /* --------------------------------- auth ------------------------------- */

  function renderMemberPicker() {
    var host = $('#member-picker');
    host.innerHTML = members.map(function (m) {
      var initials = m.name.trim().slice(0, 2).toUpperCase();
      return '<button type="button" class="member-chip' + (m.id === selectedMemberId ? ' selected' : '') +
             '" data-id="' + esc(m.id) + '" style="--chip:' + esc(m.color) + '">' +
             '<span class="avatar" style="background:' + esc(m.color) + '">' + esc(initials) + '</span>' +
             '<span class="member-name">' + esc(m.name) + '</span></button>';
    }).join('');

    $$('.member-chip', host).forEach(function (btn) {
      btn.addEventListener('click', function () {
        selectedMemberId = btn.dataset.id;
        $('#login-error').textContent = '';
        renderMemberPicker();
        $('#pin-input').focus();
      });
    });
  }

  function attemptLogin(e) {
    e.preventDefault();
    var err = $('#login-error');
    var btn = $('#login-form button[type=submit]');
    var pin = $('#pin-input').value.trim();

    err.textContent = '';
    btn.disabled = true;
    Store.signIn(pin, selectedMemberId).then(function (member) {
      session = member;
      selectedMemberId = member.id;
      $('#pin-input').value = '';
      return showPortal();
    }).catch(function (e2) {
      err.textContent = e2.message || 'That PIN did not work.';
      $('#pin-input').select();
    }).then(function () { btn.disabled = false; });
  }

  function logout() {
    Store.signOut().catch(function () {}).then(function () {
      session = null;
      apps = [];
      selectedMemberId = null;
      stopRefreshing();
      renderMemberPicker();
      $('#portal-view').classList.add('hidden');
      $('#login-view').classList.remove('hidden');
    });
  }

  function showPortal() {
    $('#login-view').classList.add('hidden');
    $('#portal-view').classList.remove('hidden');

    var who = $('#who');
    who.innerHTML = '<span class="avatar avatar-sm" style="background:' + esc(session.color) + '">' +
                    esc(session.name.slice(0, 2).toUpperCase()) + '</span> ' + esc(session.name);

    var badge = $('#mode-badge');
    if (Store.isShared()) {
      badge.className = 'mode-badge mode-shared';
      badge.textContent = 'Shared — everyone sees the same table';
      badge.title = 'Applications and documents are stored on the server, so every member sees them.';
    } else {
      badge.className = 'mode-badge mode-local';
      badge.textContent = 'This browser only';
      badge.title = 'No server behind this copy — nothing here is visible to the other members. ' +
                    'Use the portal on its web address to share.';
    }

    renderFilters();
    render();
    startRefreshing();
    refreshStorage();
    return refreshApps();
  }

  /* --------------------------------- backup ------------------------------ */

  /* Everything the portal holds, in one zip you can keep somewhere else: the
     applications as JSON and as a spreadsheet, and every document under a name
     that says which application it belongs to. */
  function csvOf(list) {
    var columns = ['Member', 'Applicant', 'Passport number', 'Indian visa type',
                   'Reference', 'Process start', 'Status', 'Note',
                   'Passport upload', 'Visa picture', 'Additional documents'];
    var cell = function (v) { return '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"'; };
    var rows = list.map(function (a) {
      return [
        memberName(a.memberId), a.applicant, a.passportNo, a.visaType, a.reference,
        fmtDateTime(a.startAt), statusLabel(a.status), a.note,
        a.passportFile ? a.passportFile.name : '',
        a.visaFile ? a.visaFile.name : '',
        (a.docs || []).map(function (d) { return d.name; }).join('; ')
      ].map(cell).join(',');
    });
    return columns.map(cell).join(',') + '\r\n' + rows.join('\r\n') + '\r\n';
  }

  function downloadBackup() {
    var btn = $('#backup-btn');
    var original = btn.textContent;
    btn.disabled = true;

    var encoder = new TextEncoder();
    var stamp = new Date();
    var list = apps.slice();
    var entries = [
      { name: 'applications.json', bytes: encoder.encode(JSON.stringify(list, null, 2)), date: stamp },
      { name: 'applications.csv', bytes: encoder.encode(csvOf(list)), date: stamp }
    ];

    /* every document on every application, named so it is obvious whose it is */
    var wanted = [];
    list.forEach(function (a, index) {
      /* numbered, so two applicants with the same name keep separate folders */
      var label = String(index + 1) + ' - ' +
        Backup.safeName(a.applicant || a.passportNo || a.id, 'application');
      [a.passportFile, a.visaFile].concat(a.docs || []).forEach(function (file, i) {
        if (!file || !file.id) return;
        var kind = i === 0 ? 'passport' : i === 1 ? 'visa' : 'document';
        wanted.push({
          id: file.id,
          path: 'documents/' + label + '/' + kind + '-' + Backup.safeName(file.name, 'file')
        });
      });
    });

    var done = 0;
    var missing = 0;
    var step = Promise.resolve();
    wanted.forEach(function (item) {
      step = step.then(function () {
        btn.textContent = 'Backup ' + Math.round((done / wanted.length) * 100) + '%';
        return Store.readFile(item.id).then(function (blob) {
          if (!blob) { missing++; return; }
          return blob.arrayBuffer().then(function (buf) {
            entries.push({ name: item.path, bytes: new Uint8Array(buf), date: stamp });
          });
        }).catch(function () { missing++; })
          .then(function () { done++; });
      });
    });

    step.then(function () {
      var blob = Backup.zip(entries);
      var url = URL.createObjectURL(blob);
      var a = document.createElement('a');
      a.href = url;
      a.download = 'dolphine-backup-' + stamp.toISOString().slice(0, 10) + '.zip';
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 60000);
      if (missing) {
        alert(missing + ' document(s) could not be read and are not in the backup. ' +
              'Everything else was saved.');
      }
    }).catch(function (err) {
      alert('The backup could not be built: ' + (err.message || err));
    }).then(function () {
      btn.disabled = false;
      btn.textContent = original;
    });
  }

  /* How much has been stored, and where — so a full store is something you see
     coming rather than something you discover mid-upload. */
  function refreshStorage() {
    var line = $('#storage-line');
    if (!Store.isShared()) { line.textContent = ''; return; }
    fetch('/api/storage', { credentials: 'same-origin' })
      .then(function (res) { return res.ok ? res.json() : null; })
      .then(function (info) {
        if (!info) return;
        line.textContent = info.documents + ' document' + (info.documents === 1 ? '' : 's') +
          ' · ' + fmtSize(info.bytes) + ' on ' +
          (info.backend === 'cloudflare-r2' ? 'Cloudflare R2' : 'Netlify Blobs') + ' · ';
      })
      .catch(function () { /* the footer simply stays quiet */ });
  }

  /* In shared mode another member may add a row at any moment, so the table
     re-reads itself periodically and whenever the window is focused again. */
  var refreshTimer = null;

  function startRefreshing() {
    if (!Store.isShared() || refreshTimer) return;
    refreshTimer = setInterval(function () {
      if (!document.hidden && !$('#modal-root').innerHTML) refreshApps();
    }, 20000);
    window.addEventListener('focus', onWindowFocus);
  }

  function stopRefreshing() {
    if (refreshTimer) { clearInterval(refreshTimer); refreshTimer = null; }
    window.removeEventListener('focus', onWindowFocus);
  }

  function onWindowFocus() {
    if (session && !$('#modal-root').innerHTML) refreshApps();
  }

  /* ------------------------------- filters ------------------------------ */

  function renderFilters() {
    var fm = $('#filter-member');
    var keptMember = fm.value;
    fm.innerHTML = '<option value="">All members</option>' + members.map(function (m) {
      return '<option value="' + esc(m.id) + '">' + esc(m.name) + '</option>';
    }).join('');
    fm.value = memberById(keptMember) ? keptMember : '';

    var fs = $('#filter-status');
    if (fs.options.length <= 1) {
      fs.innerHTML = '<option value="">All statuses</option>' + STATUSES.map(function (s) {
        return '<option value="' + s.key + '">' + esc(s.label) + '</option>';
      }).join('');
    }
  }

  function visibleApps() {
    var q = $('#search').value.trim().toLowerCase();
    var fm = $('#filter-member').value;
    var fs = $('#filter-status').value;

    return apps.filter(function (a) {
      if (fm && a.memberId !== fm) return false;
      if (fs && a.status !== fs) return false;
      if (!q) return true;
      var hay = [a.applicant, a.passportNo, a.reference, a.note, a.visaType,
                 memberName(a.memberId), statusLabel(a.status)].join(' ').toLowerCase();
      return hay.indexOf(q) !== -1;
    }).sort(function (a, b) {
      return new Date(b.startAt || b.createdAt || 0) - new Date(a.startAt || a.createdAt || 0);
    });
  }

  /* -------------------------------- render ------------------------------ */

  function renderStats() {
    var counts = {};
    apps.forEach(function (a) { counts[a.status] = (counts[a.status] || 0) + 1; });
    var cards = [{ key: 'total', label: 'Total applications', value: apps.length }]
      .concat(STATUSES.map(function (s) {
        return { key: s.key, label: s.label, value: counts[s.key] || 0 };
      }));
    $('#stats').innerHTML = cards.map(function (c) {
      return '<div class="stat stat-' + c.key + '"><span class="stat-value">' + c.value +
             '</span><span class="stat-label">' + esc(c.label) + '</span></div>';
    }).join('');
  }

  function fileChip(meta, appId, which, index) {
    if (!meta) return '';
    return '<button type="button" class="file-chip" data-open="' + esc(meta.id) + '" title="' +
           esc(meta.name + ' · ' + fmtSize(meta.size)) + '">' +
           '<span class="file-ico">📎</span><span class="file-name">' + esc(meta.name) + '</span></button>';
  }

  function statusCell(a) {
    return '<select class="status-select status-' + esc(a.status) + '" data-status-for="' + esc(a.id) + '">' +
      STATUSES.map(function (s) {
        return '<option value="' + s.key + '"' + (s.key === a.status ? ' selected' : '') + '>' +
               esc(s.label) + '</option>';
      }).join('') + '</select>';
  }

  function historyCell(a) {
    var h = a.history && a.history.length ? a.history[a.history.length - 1] : null;
    if (!h) return '<span class="muted">—</span>';
    var what = h.changes && h.changes.length
      ? h.changes.map(function (c) { return FIELD_LABELS[c.field] || c.field; }).join(', ')
      : h.action;
    return '<div class="hist">' +
      '<span class="hist-when" title="' + esc(fmtDateTime(h.at)) + '">' + esc(relative(h.at)) + '</span>' +
      '<span class="hist-by">by ' + esc(h.by) + '</span>' +
      '<span class="hist-what" title="' + esc(what) + '">' + esc(what) + '</span>' +
      '<button type="button" class="link-btn" data-history="' + esc(a.id) + '">Full history</button>' +
      '</div>';
  }

  function render() {
    renderStats();
    var list = visibleApps();
    var tbody = $('#rows');

    tbody.innerHTML = list.map(function (a, i) {
      var m = memberById(a.memberId);
      var color = m ? m.color : '#94a3b8';
      var docs = (a.docs || []);
      return '<tr data-id="' + esc(a.id) + '">' +
        '<td class="c-idx">' + (i + 1) + '</td>' +
        '<td class="c-member"><span class="pill" style="--pill:' + esc(color) + '">' +
          esc(memberName(a.memberId)) + '</span></td>' +
        '<td class="c-applicant">' + (a.applicant ? esc(a.applicant) : '<span class="muted">—</span>') + '</td>' +
        '<td class="c-passport"><span class="mono">' +
          (a.passportNo ? esc(a.passportNo) : '<span class="muted">—</span>') + '</span></td>' +
        '<td class="c-upload">' + (a.passportFile ? fileChip(a.passportFile) :
          '<span class="chip-empty">not uploaded</span>') + '</td>' +
        '<td class="c-visa">' + (a.visaType ? '<span class="visa-tag">' + esc(a.visaType) + '</span>' :
          '<span class="muted">—</span>') + '</td>' +
        '<td class="c-visadoc">' + (a.visaFile ? fileChip(a.visaFile) :
          '<span class="chip-empty">not uploaded</span>') + '</td>' +
        '<td class="c-ref">' + (a.reference ? esc(a.reference) : '<span class="muted">—</span>') + '</td>' +
        '<td class="c-start">' + (a.startAt ?
          '<span class="when">' + esc(fmtDateTime(a.startAt)) + '</span><span class="when-rel">' +
          esc(relative(a.startAt)) + '</span>' : '<span class="muted">—</span>') + '</td>' +
        '<td class="c-docs">' + (docs.length
          ? '<div class="chip-stack">' + docs.map(function (d) { return fileChip(d); }).join('') + '</div>'
          : '<span class="chip-empty">none</span>') + '</td>' +
        '<td class="c-status">' + statusCell(a) + '</td>' +
        '<td class="c-note">' + (a.note
          ? '<div class="note" title="' + esc(a.note) + '"><span>' + esc(a.note) + '</span></div>'
          : '<span class="muted">—</span>') + '</td>' +
        '<td class="c-history">' + historyCell(a) + '</td>' +
        '<td class="c-actions">' +
          '<button type="button" class="btn btn-tiny" data-edit="' + esc(a.id) + '">Edit</button>' +
          '<button type="button" class="btn btn-tiny btn-danger" data-delete="' + esc(a.id) + '">Delete</button>' +
        '</td>' +
      '</tr>';
    }).join('');

    $('#empty').classList.toggle('hidden', list.length > 0);
  }

  /* -------------------------------- history ----------------------------- */

  function diff(before, after) {
    var changes = [];
    Object.keys(FIELD_LABELS).forEach(function (field) {
      var b = before ? before[field] : undefined;
      var a = after[field];
      if (field === 'passportFile' || field === 'visaFile') {
        var bn = b ? b.name : '', an = a ? a.name : '';
        if (bn !== an) changes.push({ field: field, from: bn || '—', to: an || '—' });
        return;
      }
      if (field === 'docs') {
        var bl = (b || []).map(function (d) { return d.name; }).join(', ');
        var al = (a || []).map(function (d) { return d.name; }).join(', ');
        if (bl !== al) changes.push({ field: field, from: bl || '—', to: al || '—' });
        return;
      }
      var bv = b == null ? '' : String(b);
      var av = a == null ? '' : String(a);
      if (bv !== av) {
        if (field === 'memberId') { bv = bv ? memberName(bv) : ''; av = av ? memberName(av) : ''; }
        if (field === 'status') { bv = bv ? statusLabel(before.status) : ''; av = statusLabel(after.status); }
        if (field === 'startAt') { bv = fmtDateTime(before && before.startAt); av = fmtDateTime(after.startAt); }
        changes.push({ field: field, from: bv || '—', to: av || '—' });
      }
    });
    return changes;
  }

  function logHistory(app, action, changes) {
    app.history = app.history || [];
    app.history.push({
      at: new Date().toISOString(),
      by: session.name,
      action: action,
      changes: changes || []
    });
  }

  function openHistory(id) {
    var a = apps.filter(function (x) { return x.id === id; })[0];
    if (!a) return;
    var entries = (a.history || []).slice().reverse();
    var body = entries.length ? entries.map(function (h) {
      var rows = (h.changes || []).map(function (c) {
        return '<li><strong>' + esc(FIELD_LABELS[c.field] || c.field) + ':</strong> ' +
               '<span class="from">' + esc(c.from) + '</span> → <span class="to">' + esc(c.to) + '</span></li>';
      }).join('');
      return '<li class="timeline-item">' +
        '<div class="timeline-head"><span class="timeline-action">' + esc(h.action) + '</span>' +
        '<span class="timeline-meta">' + esc(fmtDateTime(h.at)) + ' · ' + esc(h.by) + '</span></div>' +
        (rows ? '<ul class="timeline-changes">' + rows + '</ul>' : '') + '</li>';
    }).join('') : '<li class="muted">No history recorded yet.</li>';

    openModal({
      title: 'Change history — ' + (a.applicant || a.passportNo || 'application'),
      html: '<ul class="timeline">' + body + '</ul>',
      actions: '<button type="button" class="btn btn-primary" data-close>Close</button>'
    });
  }

  /* --------------------------------- modal ------------------------------ */

  function closeModal() { $('#modal-root').innerHTML = ''; }

  function openModal(opts) {
    var root = $('#modal-root');
    root.innerHTML =
      '<div class="modal-backdrop">' +
        '<div class="modal' + (opts.wide ? ' modal-wide' : '') + '" role="dialog" aria-modal="true">' +
          '<header class="modal-head"><h2>' + esc(opts.title) + '</h2>' +
            '<button type="button" class="icon-btn" data-close aria-label="Close">✕</button></header>' +
          '<div class="modal-body">' + opts.html + '</div>' +
          '<footer class="modal-foot">' + (opts.actions || '') + '</footer>' +
        '</div>' +
      '</div>';

    $$('[data-close]', root).forEach(function (b) { b.addEventListener('click', closeModal); });
    $('.modal-backdrop', root).addEventListener('mousedown', function (e) {
      if (e.target === e.currentTarget) closeModal();
    });
    return root;
  }

  /* ----------------------------- application form ----------------------- */

  function openForm(id) {
    var existing = id ? apps.filter(function (x) { return x.id === id; })[0] : null;
    var draft = {
      passportFile: existing && existing.passportFile ? existing.passportFile : null,
      visaFile: existing && existing.visaFile ? existing.visaFile : null,
      docs: existing && existing.docs ? existing.docs.slice() : []
    };
    var removedIds = [];

    var html =
      '<form id="app-form" class="form-grid" autocomplete="off">' +
        field('Member', '<select name="memberId" class="input" required>' + members.map(function (m) {
          var sel = existing ? existing.memberId === m.id : m.id === session.id;
          return '<option value="' + esc(m.id) + '"' + (sel ? ' selected' : '') + '>' + esc(m.name) + '</option>';
        }).join('') + '</select>') +
        field('Applicant name', '<input name="applicant" class="input" placeholder="Full name as in passport" value="' +
          esc(existing && existing.applicant) + '" />') +
        field('Passport number', '<input name="passportNo" class="input mono" placeholder="A1234567" value="' +
          esc(existing && existing.passportNo) + '" required />') +
        field('Indian visa type', '<select name="visaType" class="input">' +
          '<option value="">— select —</option>' + VISA_TYPES.map(function (v) {
            return '<option value="' + esc(v) + '"' +
              (existing && existing.visaType === v ? ' selected' : '') + '>' + esc(v) + '</option>';
          }).join('') + '</select>') +
        field('Reference (who is giving it)', '<input name="reference" class="input" placeholder="Name / agency" value="' +
          esc(existing && existing.reference) + '" />') +
        field('Application process start', '<input name="startAt" type="datetime-local" class="input" value="' +
          esc(isoToLocalInput(existing ? existing.startAt : new Date().toISOString())) + '" />') +
        field('Status', '<select name="status" class="input">' + STATUSES.map(function (s) {
          var sel = existing ? existing.status === s.key : s.key === 'draft';
          return '<option value="' + s.key + '"' + (sel ? ' selected' : '') + '>' + esc(s.label) + '</option>';
        }).join('') + '</select>') +
        '<div class="field field-wide"><label>Passport upload</label>' +
          '<div id="passport-slot" class="upload-slot"></div>' +
          '<input type="file" name="passportFile" class="file-input" accept="image/*,.pdf" /></div>' +
        '<div class="field field-wide"><label>Indian visa picture</label>' +
          '<div id="visa-slot" class="upload-slot"></div>' +
          '<input type="file" name="visaFile" class="file-input" accept="image/*,.pdf" /></div>' +
        '<div class="field field-wide"><label>Additional documents</label>' +
          '<div id="docs-slot" class="upload-slot"></div>' +
          '<input type="file" name="docs" class="file-input" multiple accept="image/*,.pdf,.doc,.docx" /></div>' +
        '<div class="field field-wide"><label>Note</label>' +
          '<textarea name="note" class="input" rows="3" placeholder="Anything the team should know…">' +
          esc(existing && existing.note) + '</textarea></div>' +
      '</form>';

    openModal({
      title: existing ? 'Edit application' : 'New application',
      html: html,
      wide: true,
      actions: '<button type="button" class="btn btn-ghost" data-close>Cancel</button>' +
               '<button type="submit" form="app-form" class="btn btn-primary">' +
               (existing ? 'Save changes' : 'Create application') + '</button>'
    });

    function field(label, control) {
      return '<div class="field"><label>' + esc(label) + '</label>' + control + '</div>';
    }

    function renderSlots() {
      $('#passport-slot').innerHTML = draft.passportFile
        ? '<span class="file-chip file-chip-static">📎 ' + esc(draft.passportFile.name) +
          '<button type="button" class="chip-x" data-drop-passport>✕</button></span>'
        : '<span class="chip-empty">No passport file yet — choose one below.</span>';

      $('#visa-slot').innerHTML = draft.visaFile
        ? '<span class="file-chip file-chip-static">📎 ' + esc(draft.visaFile.name) +
          '<button type="button" class="chip-x" data-drop-visa>✕</button></span>'
        : '<span class="chip-empty">No visa picture yet — add it once the visa is issued.</span>';

      $('#docs-slot').innerHTML = draft.docs.length
        ? draft.docs.map(function (d, i) {
            return '<span class="file-chip file-chip-static">📎 ' + esc(d.name) +
                   '<button type="button" class="chip-x" data-drop-doc="' + i + '">✕</button></span>';
          }).join('')
        : '<span class="chip-empty">No additional documents yet.</span>';

      var v = $('[data-drop-visa]');
      if (v) v.addEventListener('click', function () {
        if (draft.visaFile) removedIds.push(draft.visaFile.id);
        draft.visaFile = null;
        renderSlots();
      });

      var p = $('[data-drop-passport]');
      if (p) p.addEventListener('click', function () {
        if (draft.passportFile) removedIds.push(draft.passportFile.id);
        draft.passportFile = null;
        renderSlots();
      });
      $$('[data-drop-doc]').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var i = Number(btn.dataset.dropDoc);
          if (draft.docs[i]) removedIds.push(draft.docs[i].id);
          draft.docs.splice(i, 1);
          renderSlots();
        });
      });
    }
    renderSlots();

    $('#app-form').addEventListener('submit', function (e) {
      e.preventDefault();
      var form = e.currentTarget;
      var submitBtn = $('[form="app-form"]');
      if (submitBtn) { submitBtn.disabled = true; submitBtn.textContent = 'Saving…'; }

      var by = session.name;
      var newPassport = form.passportFile.files[0] || null;
      var newVisa = form.visaFile.files[0] || null;
      var newDocs = Array.prototype.slice.call(form.docs.files || []);

      var jobs = [];
      if (newPassport) {
        jobs.push(Store.saveFile(newPassport, by).then(function (meta) {
          if (draft.passportFile) removedIds.push(draft.passportFile.id);
          draft.passportFile = meta;
        }));
      }
      if (newVisa) {
        jobs.push(Store.saveFile(newVisa, by).then(function (meta) {
          if (draft.visaFile) removedIds.push(draft.visaFile.id);
          draft.visaFile = meta;
        }));
      }
      newDocs.forEach(function (f) {
        jobs.push(Store.saveFile(f, by).then(function (meta) { draft.docs.push(meta); }));
      });

      Promise.all(jobs).then(function () {
        var payload = {
          memberId: form.memberId.value,
          applicant: form.applicant.value.trim(),
          passportNo: form.passportNo.value.trim(),
          visaType: form.visaType.value,
          reference: form.reference.value.trim(),
          startAt: localInputToIso(form.startAt.value),
          status: form.status.value,
          note: form.note.value.trim(),
          passportFile: draft.passportFile,
          visaFile: draft.visaFile,
          docs: draft.docs
        };

        var saved;
        if (existing) {
          var changes = diff(existing, payload);
          Object.keys(payload).forEach(function (k) { existing[k] = payload[k]; });
          if (changes.length) logHistory(existing, 'Updated', changes);
          saved = existing;
        } else {
          saved = Object.assign({
            id: uid('app'),
            createdAt: new Date().toISOString(),
            createdBy: by,
            history: []
          }, payload);
          logHistory(saved, 'Created', []);
          apps.push(saved);
        }

        return persist(saved).then(function () {
          return Promise.all(removedIds.map(function (fid) { return Store.deleteFile(fid); }));
        });
      }).then(function () {
        closeModal();
        render();
      }).catch(function (err) {
        console.error(err);
        /* upload problems explain themselves; anything else needs framing */
        alert(err && err.message ? err.message : 'This application could not be saved.');
        if (submitBtn) {
          submitBtn.disabled = false;
          submitBtn.textContent = existing ? 'Save changes' : 'Create application';
        }
      });
    });
  }

  function deleteApp(id) {
    var a = apps.filter(function (x) { return x.id === id; })[0];
    if (!a) return;
    var label = a.applicant || a.passportNo || 'this application';
    if (!confirm('Delete ' + label + '? Its uploaded files are removed too. This cannot be undone.')) return;
    Store.deleteApp(id).then(function () {
      /* the server removes the documents with the application; in browser-only
         mode they have to be cleared here */
      if (Store.isShared()) return;
      var ids = [];
      if (a.passportFile) ids.push(a.passportFile.id);
      if (a.visaFile) ids.push(a.visaFile.id);
      (a.docs || []).forEach(function (d) { ids.push(d.id); });
      return Promise.all(ids.map(function (fid) { return Store.deleteFile(fid); }));
    }).then(function () {
      apps = apps.filter(function (x) { return x.id !== id; });
      render();
      refreshStorage();
    }).catch(function (err) {
      alert('That application could not be deleted: ' + err.message);
    });
  }

  /* -------------------------------- members ----------------------------- */

  function openMembers() {
    function body() {
      return '<ul class="member-list">' + members.map(function (m) {
        var count = apps.filter(function (a) { return a.memberId === m.id; }).length;
        return '<li><span class="avatar" style="background:' + esc(m.color) + '">' +
          esc(m.name.slice(0, 2).toUpperCase()) + '</span>' +
          '<span class="member-list-name">' + esc(m.name) + '</span>' +
          '<span class="muted">' + count + ' application' + (count === 1 ? '' : 's') + '</span>' +
          (m.id === session.id
            ? '<span class="tag-you">you</span>'
            : Store.isShared() ? ''
            : '<button type="button" class="btn btn-tiny btn-danger" data-remove-member="' + esc(m.id) + '">Remove</button>') +
        '</li>';
      }).join('') + '</ul>' +
      (Store.isShared()
        ? '<p class="modal-hint">Members of the shared portal are set in Netlify, under ' +
          '<strong>Site configuration → Environment variables → PORTAL_PINS</strong>, in the form ' +
          '<code>sam=1111,topu=2222,kawser=1568</code>. Add a name and PIN there and redeploy, and ' +
          'the new member can sign in from anywhere.</p>'
        : '<form id="member-form" class="member-form" autocomplete="off">' +
          '<input name="name" class="input" placeholder="New member name" required />' +
          '<input name="pin" class="input" placeholder="Access PIN" inputmode="numeric" required />' +
          '<button type="submit" class="btn btn-primary">Add member</button>' +
        '</form>' +
        '<p class="modal-hint">This copy of the portal keeps members in this browser only. ' +
        'PINs here gate the screen — they are not real authentication.</p>');
    }

    function wire() {
      var form = $('#member-form');
      if (form) form.addEventListener('submit', onAddMember);

      $$('[data-remove-member]').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var id = btn.dataset.removeMember;
          var count = apps.filter(function (a) { return a.memberId === id; }).length;
          var msg = 'Remove ' + memberName(id) + ' from the portal?' +
            (count ? ' Their ' + count + ' application(s) stay in the table.' : '');
          if (!confirm(msg)) return;
          Store.removeMember(id).then(function (list) {
            members = list;
            refresh();
            renderFilters();
            render();
          }).catch(function (err) { alert(err.message); });
        });
      });

      function onAddMember(e) {
        e.preventDefault();
        var name = e.currentTarget.name.value.trim();
        var pin = e.currentTarget.pin.value.trim();
        if (!name || !pin) return;
        var id = name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
        if (memberById(id)) { alert('A member with that name already exists.'); return; }
        var colors = Store.memberColors;
        Store.addMember({ id: id, name: name, pin: pin, color: colors[members.length % colors.length] })
          .then(function (list) {
            members = list;
            refresh();
            renderFilters();
            render();
          }).catch(function (err) { alert(err.message); });
      }
    }

    function refresh() {
      $('.modal-body').innerHTML = body();
      wire();
    }

    openModal({
      title: 'Portal members',
      html: body(),
      actions: '<button type="button" class="btn btn-primary" data-close>Done</button>'
    });
    wire();
  }

  /* -------------------------------- events ------------------------------ */

  function onTableClick(e) {
    var t = e.target.closest('[data-edit],[data-delete],[data-history],[data-open]');
    if (!t) return;
    if (t.dataset.edit) openForm(t.dataset.edit);
    else if (t.dataset.delete) deleteApp(t.dataset.delete);
    else if (t.dataset.history) openHistory(t.dataset.history);
    else if (t.dataset.open) Store.openFile(t.dataset.open);
  }

  function onStatusChange(e) {
    var sel = e.target.closest('[data-status-for]');
    if (!sel) return;
    var a = apps.filter(function (x) { return x.id === sel.dataset.statusFor; })[0];
    if (!a || a.status === sel.value) return;
    var from = statusLabel(a.status);
    a.status = sel.value;
    logHistory(a, 'Status changed', [{ field: 'status', from: from, to: statusLabel(a.status) }]);
    render();
    persist(a);
  }

  /* ----------------------------- opening photo -------------------------- */

  var heroIsCustom = false;

  function applyHero(src, custom) {
    document.documentElement.style.setProperty('--hero', 'url("' + src + '")');
    $('#login-view').classList.add('has-photo');
    heroIsCustom = !!custom;
    $('#hero-reset').classList.toggle('hidden', !custom);
  }

  function clearHero() {
    var done = Store.isShared()
      ? fetch('/api/hero', { method: 'DELETE', credentials: 'same-origin' }).catch(function () {})
      : Promise.resolve(localStorage.removeItem(KEY_HERO));
    return done.then(function () {
      document.documentElement.style.removeProperty('--hero');
      $('#login-view').classList.remove('has-photo');
      $('#hero-reset').classList.add('hidden');
      heroIsCustom = false;
      loadHero();
    });
  }

  /* Swap in the photo only once it has actually loaded, so a missing file
     leaves the painted scene untouched instead of flashing an empty frame.
     On the shared portal the photo comes from the server, so whoever sets it
     sets it for everyone. */
  function loadHero() {
    if (Store.isShared()) {
      fetch('/api/hero', { credentials: 'same-origin' })
        .then(function (res) { return res.ok ? res.json() : null; })
        .then(function (body) { if (body && body.image) applyHero(body.image, true); })
        .catch(function () { /* the painted scene stays */ });
      return;
    }
    var stored = localStorage.getItem(KEY_HERO);
    if (stored) { applyHero(stored, true); return; }
    if (!HERO_IMAGE) return;
    var img = new Image();
    img.onload = function () { applyHero(HERO_IMAGE, false); };
    img.src = HERO_IMAGE;
  }

  /* Downscales the chosen photo before storing it — a phone camera original
     would blow past the localStorage quota as base64. */
  function shrinkImage(file) {
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();
      reader.onerror = function () { reject(new Error('The file could not be read.')); };
      reader.onload = function () {
        var img = new Image();
        img.onerror = function () { reject(new Error('That file is not an image this browser can open.')); };
        img.onload = function () {
          var scale = Math.min(1, HERO_MAX_WIDTH / img.naturalWidth);
          var canvas = document.createElement('canvas');
          canvas.width = Math.round(img.naturalWidth * scale);
          canvas.height = Math.round(img.naturalHeight * scale);
          canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
          resolve(canvas.toDataURL('image/jpeg', 0.82));
        };
        img.src = reader.result;
      };
      reader.readAsDataURL(file);
    });
  }

  /* Accepts the photo however it arrives: the file picker, a drag onto the
     page, or a paste. */
  /* Choosing the opening photo for everyone means proving who you are, and the
     sign-in screen is by definition signed out — so on the shared portal the
     control lives inside, in the top bar. */
  function openPhotoPanel() {
    var current = document.documentElement.style.getPropertyValue('--hero');
    openModal({
      title: 'Opening photo',
      html: '<p class="modal-hint" style="margin-top:0">This is the picture every member sees on the ' +
              'sign-in screen. Choosing one here replaces it for all of them.</p>' +
            (current
              ? '<div class="photo-preview" style="background-image:' + current + '"></div>'
              : '<div class="photo-preview photo-preview-empty">No photo yet — the painted ocean scene is showing.</div>') +
            '<div class="photo-actions">' +
              '<label class="btn btn-primary">' +
                '<input id="photo-input" type="file" accept="image/*" hidden /> Choose a photo</label>' +
              (heroIsCustom
                ? '<button type="button" class="btn btn-ghost" id="photo-remove">Remove photo</button>'
                : '') +
            '</div>',
      actions: '<button type="button" class="btn btn-primary" data-close>Done</button>'
    });

    $('#photo-input').addEventListener('change', function (e) {
      var file = e.target.files[0];
      e.target.value = '';
      if (file) chooseHero(file).then(function () { closeModal(); });
    });
    var remove = $('#photo-remove');
    if (remove) remove.addEventListener('click', function () {
      clearHero().then(closeModal);
    });
  }

  function wireHeroDropAndPaste() {
    var view = $('#login-view');
    var veil = $('#drop-veil');
    var depth = 0;

    function onLogin() { return !view.classList.contains('hidden'); }

    function firstImage(list) {
      for (var i = 0; i < (list ? list.length : 0); i++) {
        if (list[i] && /^image\//.test(list[i].type)) return list[i];
      }
      return null;
    }

    view.addEventListener('dragenter', function (e) {
      if (!onLogin()) return;
      e.preventDefault();
      depth++;
      veil.classList.add('showing');
    });
    view.addEventListener('dragover', function (e) { if (onLogin()) e.preventDefault(); });
    view.addEventListener('dragleave', function () {
      depth = Math.max(0, depth - 1);
      if (!depth) veil.classList.remove('showing');
    });
    view.addEventListener('drop', function (e) {
      if (!onLogin()) return;
      e.preventDefault();
      depth = 0;
      veil.classList.remove('showing');
      var file = firstImage(e.dataTransfer && e.dataTransfer.files);
      if (file) chooseHero(file);
      else alert('Drop an image file (JPG or PNG) to use it as the opening screen.');
    });

    document.addEventListener('paste', function (e) {
      if (!onLogin() || $('#modal-root').innerHTML) return;
      var data = e.clipboardData;
      if (!data) return;
      var file = firstImage(data.files);
      if (!file && data.items) {
        for (var i = 0; i < data.items.length; i++) {
          if (/^image\//.test(data.items[i].type)) { file = data.items[i].getAsFile(); break; }
        }
      }
      if (file) { e.preventDefault(); chooseHero(file); }
    });
  }

  function chooseHero(file) {
    if (!file) return Promise.resolve();
    return shrinkImage(file).then(function (dataUrl) {
      if (Store.isShared()) {
        return fetch('/api/hero', {
          method: 'PUT',
          credentials: 'same-origin',
          headers: { 'content-type': 'application/json' },
          body: JSON.stringify({ image: dataUrl })
        }).then(function (res) {
          if (res.status === 401) throw new Error('Sign in first, then set the opening photo for everyone.');
          if (!res.ok) throw new Error('That photo could not be saved for the team.');
          applyHero(dataUrl, true);
        });
      }
      try { localStorage.setItem(KEY_HERO, dataUrl); }
      catch (e) {
        throw new Error('That photo is too large to store. Try a smaller image, or save it ' +
                        'as assets/dolphin.jpg next to index.html instead.');
      }
      applyHero(dataUrl, true);
    }).catch(function (err) { alert(err.message); });
  }

  function init() {
    wireEvents();
    $('#login-error').textContent = 'Loading…';

    Store.init().then(function () {
      if (Store.isShared()) {
        $('.hero-tools').classList.add('hidden');
        $('.login-foot p').textContent =
          'Signed-in members share one table — applications and documents are visible to everybody.';
      }
      loadHero();
      return loadAll();
    }).then(function () {
      $('#login-error').textContent = '';
      renderMemberPicker();
      if (session) return showPortal();
    }).catch(function (err) {
      $('#login-error').textContent = 'The portal could not start: ' + err.message;
    });
  }

  function wireEvents() {
    $('#login-form').addEventListener('submit', attemptLogin);
    $('#hero-input').addEventListener('change', function (e) {
      chooseHero(e.target.files[0]);
      e.target.value = '';
    });
    $('#hero-reset').addEventListener('click', clearHero);
    wireHeroDropAndPaste();
    $('#logout-btn').addEventListener('click', logout);
    $('#add-btn').addEventListener('click', function () { openForm(null); });
    $('#members-btn').addEventListener('click', openMembers);
    $('#photo-btn').addEventListener('click', openPhotoPanel);
    $('#backup-btn').addEventListener('click', downloadBackup);
    $('#search').addEventListener('input', render);
    $('#filter-member').addEventListener('change', render);
    $('#filter-status').addEventListener('change', render);
    $('#rows').addEventListener('click', onTableClick);
    $('#rows').addEventListener('change', onStatusChange);
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') closeModal();
    });
  }

  document.addEventListener('DOMContentLoaded', init);
})();
