/* Dolphine portal API — runs on Netlify Functions, stores everything in
   Netlify Blobs so every member sees the same applications and documents.

   Routes (all under /api):
     GET    /api/members        public: names + colours, never PINs
     GET    /api/session        who am I
     POST   /api/session        { pin } -> sign in
     DELETE /api/session        sign out
     GET    /api/apps           every application
     PUT    /api/apps/:id       create or replace one application
     DELETE /api/apps/:id       delete one application and its documents
     POST   /api/files          raw body upload, name/type in headers
     GET    /api/files/:id      stream a document back
     DELETE /api/files/:id      delete a document
*/

import { getStore } from '@netlify/blobs';
import crypto from 'node:crypto';
import { documentsBackend } from './lib/documents.mjs';

export const config = { path: '/api/*' };

/* ------------------------------- members -------------------------------- */

const DEFAULT_MEMBERS = [
  { id: 'sam', name: 'Sam', color: '#0ea5e9', pin: '1111' },
  { id: 'topu', name: 'Topu', color: '#f59e0b', pin: '2222' },
  { id: 'kawser', name: 'Kawser', color: '#ec4899', pin: '1568' }
];

const EXTRA_COLORS = ['#10b981', '#8b5cf6', '#ef4444', '#14b8a6', '#f97316', '#6366f1'];

/* PORTAL_PINS lets the PINs live in Netlify's environment instead of the
   repository: "sam=1111,topu=2222,kawser=1568". Ids that are not in the
   built-in list are added as new members. */
function members() {
  const list = DEFAULT_MEMBERS.map((m) => ({ ...m }));
  const raw = process.env.PORTAL_PINS;
  if (!raw) return list;

  for (const pair of raw.split(',')) {
    const [rawId, pin] = pair.split('=').map((s) => (s || '').trim());
    if (!rawId || !pin) continue;
    const id = rawId.toLowerCase();
    const existing = list.find((m) => m.id === id);
    if (existing) existing.pin = pin;
    else list.push({
      id,
      name: rawId.charAt(0).toUpperCase() + rawId.slice(1),
      color: EXTRA_COLORS[list.length % EXTRA_COLORS.length],
      pin
    });
  }
  return list;
}

function publicMembers() {
  return members().map(({ id, name, color }) => ({ id, name, color }));
}

/* -------------------------------- stores -------------------------------- */

const dataStore = () => getStore({ name: 'dolphine-data', consistency: 'strong' });

/* Documents go to Cloudflare R2 when it is configured, and to Netlify Blobs
   otherwise — see documents.mjs. Upload pieces are always staged in Blobs,
   since they exist only for the seconds between the first chunk and the last. */
const documents = () => documentsBackend();
const chunkStore = () => getStore({ name: 'dolphine-chunks', consistency: 'strong' });

/* The cookie signing secret is generated once and kept in the blob store, so
   there is nothing extra to configure for a working sign-in. */
async function secret() {
  if (process.env.PORTAL_SECRET) return process.env.PORTAL_SECRET;
  const store = dataStore();
  const existing = await store.get('auth-secret');
  if (existing) return existing;
  const created = crypto.randomBytes(32).toString('hex');
  await store.set('auth-secret', created);
  return created;
}

/* --------------------------------- auth --------------------------------- */

const COOKIE = 'dolphine_session';
const SESSION_DAYS = 30;

function sign(value, key) {
  return crypto.createHmac('sha256', key).update(value).digest('hex');
}

function safeEqual(a, b) {
  const ab = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ab.length !== bb.length) return false;
  return crypto.timingSafeEqual(ab, bb);
}

async function makeToken(memberId) {
  const expires = Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000;
  const body = `${memberId}.${expires}`;
  return `${body}.${sign(body, await secret())}`;
}

async function readToken(token) {
  if (!token) return null;
  const parts = String(token).split('.');
  if (parts.length !== 3) return null;
  const [memberId, expires, mac] = parts;
  if (!safeEqual(mac, sign(`${memberId}.${expires}`, await secret()))) return null;
  if (Number(expires) < Date.now()) return null;
  return members().find((m) => m.id === memberId) || null;
}

function cookieFrom(req) {
  const header = req.headers.get('cookie') || '';
  for (const part of header.split(';')) {
    const [name, ...rest] = part.trim().split('=');
    if (name === COOKIE) return rest.join('=');
  }
  return null;
}

function sessionCookie(token, maxAgeSeconds) {
  return `${COOKIE}=${token}; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=${maxAgeSeconds}`;
}

async function currentMember(req) {
  return readToken(cookieFrom(req));
}

/* ------------------------------- responses ------------------------------ */

const json = (body, status = 200, headers = {}) =>
  new Response(JSON.stringify(body), {
    status,
    headers: { 'content-type': 'application/json', 'cache-control': 'no-store', ...headers }
  });

const noContent = (headers = {}) => new Response(null, { status: 204, headers });
const unauthorized = () => json({ error: 'Sign in first.' }, 401);

/* -------------------------------- routing ------------------------------- */

export default async function handler(req) {
  const url = new URL(req.url);
  const segments = url.pathname.replace(/^\/api\/?/, '').split('/').filter(Boolean);
  const [resource, id] = segments;
  const method = req.method.toUpperCase();

  try {
    if (resource === 'members' && method === 'GET') return json(publicMembers());
    if (resource === 'session') return sessionRoute(req, method);
    if (resource === 'apps') return appsRoute(req, method, id);
    if (resource === 'files') return filesRoute(req, method, id);
    if (resource === 'hero') return heroRoute(req, method);
    if (resource === 'storage' && method === 'GET') return storageRoute(req);
    return json({ error: 'Unknown endpoint.' }, 404);
  } catch (err) {
    console.error('portal api failed', err);
    return json({ error: 'The portal could not complete that request.' }, 500);
  }
}

/* -------------------------------- storage ------------------------------- */

/* Where documents are being kept, so the portal can say so rather than leaving
   you to guess whether the R2 settings took effect. */
async function storageRoute(req) {
  const member = await currentMember(req);
  if (!member) return unauthorized();

  const store = dataStore();
  const { blobs } = await store.list({ prefix: APP_PREFIX });
  const apps = await Promise.all(
    blobs.map((b) => store.get(b.key, { type: 'json' }).catch(() => null))
  );

  let documentCount = 0;
  let bytes = 0;
  for (const app of apps.filter(Boolean)) {
    for (const file of [app.passportFile, app.visaFile, ...(app.docs || [])]) {
      if (!file || !file.id) continue;
      documentCount++;
      bytes += Number(file.size) || 0;
    }
  }

  return json({
    backend: documents().kind,
    applications: apps.filter(Boolean).length,
    documents: documentCount,
    bytes
  });
}

/* ------------------------------ opening photo --------------------------- */

/* Readable by anyone — it is the picture on the sign-in screen, before anybody
   has signed in. Only a signed-in member can change it. */
const HERO_KEY = 'hero-image';
const MAX_HERO = 4 * 1024 * 1024;

async function heroRoute(req, method) {
  const store = dataStore();

  if (method === 'GET') {
    const image = await store.get(HERO_KEY);
    return json({ image: image || null }, 200, { 'cache-control': 'private, max-age=60' });
  }

  const member = await currentMember(req);
  if (!member) return unauthorized();

  if (method === 'PUT') {
    const body = await req.json().catch(() => ({}));
    const image = String(body.image || '');
    if (!/^data:image\//.test(image)) return json({ error: 'Send the photo as a data URI.' }, 400);
    if (image.length > MAX_HERO) return json({ error: 'That photo is too large.' }, 413);
    await store.set(HERO_KEY, image);
    return json({ ok: true });
  }

  if (method === 'DELETE') {
    await store.delete(HERO_KEY);
    return noContent();
  }

  return json({ error: 'Unsupported method.' }, 405);
}

/* -------------------------------- session ------------------------------- */

async function sessionRoute(req, method) {
  if (method === 'GET') {
    /* Asking who is signed in is a question, not an error — answering 401 here
       would put a red line in every visitor's console. */
    const member = await currentMember(req);
    if (!member) return json({ member: null });
    const { id, name, color } = member;
    return json({ member: { id, name, color } });
  }

  if (method === 'POST') {
    const body = await req.json().catch(() => ({}));
    const pin = String(body.pin || '').trim();
    const matches = members().filter((m) => pin && safeEqual(m.pin, pin));
    if (matches.length !== 1) {
      return json({ error: 'That PIN does not match a member.' }, 401);
    }
    const member = matches[0];
    const token = await makeToken(member.id);
    return json(
      { id: member.id, name: member.name, color: member.color },
      200,
      { 'set-cookie': sessionCookie(token, SESSION_DAYS * 24 * 60 * 60) }
    );
  }

  if (method === 'DELETE') return noContent({ 'set-cookie': sessionCookie('', 0) });
  return json({ error: 'Unsupported method.' }, 405);
}

/* ------------------------------ applications ---------------------------- */

const APP_PREFIX = 'apps/';

async function appsRoute(req, method, id) {
  const member = await currentMember(req);
  if (!member) return unauthorized();
  const store = dataStore();

  if (method === 'GET') {
    const { blobs } = await store.list({ prefix: APP_PREFIX });
    const apps = await Promise.all(
      blobs.map((b) => store.get(b.key, { type: 'json' }).catch(() => null))
    );
    return json(apps.filter(Boolean));
  }

  if (!id) return json({ error: 'Which application?' }, 400);

  if (method === 'PUT') {
    const app = await req.json().catch(() => null);
    if (!app || typeof app !== 'object') return json({ error: 'Send the application as JSON.' }, 400);
    app.id = id;
    await store.setJSON(APP_PREFIX + id, app);
    return json(app);
  }

  if (method === 'DELETE') {
    const app = await store.get(APP_PREFIX + id, { type: 'json' }).catch(() => null);
    if (app) {
      const fileIds = [
        app.passportFile && app.passportFile.id,
        app.visaFile && app.visaFile.id,
        ...(app.docs || []).map((d) => d && d.id)
      ].filter(Boolean);
      const files = documents();
      await Promise.all(fileIds.map((fid) => files.remove(fid).catch(() => {})));
    }
    await store.delete(APP_PREFIX + id);
    return noContent();
  }

  return json({ error: 'Unsupported method.' }, 405);
}

/* -------------------------------- documents ----------------------------- */

const MAX_UPLOAD = 25 * 1024 * 1024;
const MAX_CHUNKS = 16;

/* A request body that reaches a Netlify Function is capped well below the size
   of a scanned passport, so anything large arrives in pieces and is joined back
   together here. */
async function filesRoute(req, method, id) {
  const member = await currentMember(req);
  if (!member) return unauthorized();
  const store = documents();

  if (method === 'POST') {
    const name = decodeURIComponent(req.headers.get('x-file-name') || 'document');
    const type = req.headers.get('x-file-type') || 'application/octet-stream';
    const uploadId = req.headers.get('x-upload-id') || '';
    const chunkIndex = Number(req.headers.get('x-chunk-index') || 0);
    const chunkCount = Number(req.headers.get('x-chunk-count') || 1);
    const bytes = new Uint8Array(await req.arrayBuffer());

    if (!bytes.length) return json({ error: 'That file arrived empty.' }, 400);
    if (!Number.isInteger(chunkCount) || chunkCount < 1 || chunkCount > MAX_CHUNKS) {
      return json({ error: 'That file is too large for the portal.' }, 413);
    }

    const finish = async (data) => {
      if (data.length > MAX_UPLOAD) {
        return json({ error: 'That file is larger than 25 MB. Please upload a smaller scan.' }, 413);
      }
      const meta = {
        id: crypto.randomUUID(),
        name,
        size: data.length,
        type,
        uploadedBy: member.name,
        uploadedAt: new Date().toISOString()
      };
      await store.put(meta.id, data, meta);
      return json(meta, 201);
    };

    if (chunkCount === 1) return finish(bytes);

    if (!uploadId || !/^[\w-]{6,64}$/.test(uploadId)) {
      return json({ error: 'That upload is missing its identifier.' }, 400);
    }
    if (!Number.isInteger(chunkIndex) || chunkIndex < 0 || chunkIndex >= chunkCount) {
      return json({ error: 'That upload arrived out of order.' }, 400);
    }

    const staging = chunkStore();
    const chunkKey = (i) => `${uploadId}/${i}`;
    await staging.set(chunkKey(chunkIndex), bytes);
    if (chunkIndex < chunkCount - 1) return json({ received: chunkIndex }, 202);

    /* last piece: put the file back together, then tidy the pieces away */
    const parts = [];
    for (let i = 0; i < chunkCount; i++) {
      const part = await staging.get(chunkKey(i), { type: 'arrayBuffer' }).catch(() => null);
      if (!part) return json({ error: 'Part of that upload went missing. Please try again.' }, 400);
      parts.push(new Uint8Array(part));
    }
    const total = parts.reduce((n, part) => n + part.length, 0);
    const joined = new Uint8Array(total);
    let at = 0;
    for (const part of parts) { joined.set(part, at); at += part.length; }
    await Promise.all(parts.map((_, i) => staging.delete(chunkKey(i)).catch(() => {})));
    return finish(joined);
  }

  if (!id) return json({ error: 'Which document?' }, 400);

  if (method === 'GET') {
    const found = await store.get(id).catch(() => null);
    if (!found) return json({ error: 'That document is no longer stored.' }, 404);
    const meta = found.metadata || {};
    /* A filename may be in any script — Bengali, Arabic, anything — but an HTTP
       header may not. Send a plain-ASCII name for old clients and the real one
       alongside it, the way RFC 5987 prescribes. */
    const rawName = String(meta.name || 'document');
    const asciiName = rawName.replace(/[^\x20-\x7E]/g, '_').replace(/["\\]/g, '') || 'document';
    return new Response(found.data, {
      headers: {
        'content-type': meta.type || 'application/octet-stream',
        'content-disposition':
          `inline; filename="${asciiName}"; filename*=UTF-8''${encodeURIComponent(rawName)}`,
        'cache-control': 'private, max-age=300'
      }
    });
  }

  if (method === 'DELETE') {
    await store.remove(id);
    return noContent();
  }

  return json({ error: 'Unsupported method.' }, 405);
}
